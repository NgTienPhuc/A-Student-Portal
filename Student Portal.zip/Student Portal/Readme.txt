521k0102 - Nguyễn Quốc Huy
521k0114 - Nguyễn Tiến Phúc
521k0178 - Lê Thái Gia Bảo	

Admin login attempt:
+ Username: Admin
+ Password: 123

Teacher login attempt:
+ Username: Emily
+ Password: 123

Student login attempt:
+ Username: Van A10
+ Password: 123

+ Username: Van A12
+ Password: 123

Accountant login attempt:
+ Username: Alex
+ Password: 123

Academic affair login attempt:
+ Username: Richard
+ Password: 123

Instructions:
+ Import the database via studatabase.sql (using Xampp).
+ Run Xampp apache and Xampp Mysql.
+ Run my app as http://localhost/SchoolApp/